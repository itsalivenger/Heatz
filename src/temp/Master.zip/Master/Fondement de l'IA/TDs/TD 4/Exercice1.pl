ordonnee([]).
ordonnee([_]).
ordonnee([A, B | Rest]) :- A =< B, ordonnee([B | Rest]).

doubler([], []).
doubler([X], [X, X]).
doubler([X | L], [X, X | L1]) :-
    doubler(L, L1).


% Facts defining candidates
% homme(nom, taille, couleur_cheveux, age)
homme(luc, grand, blond, mur).
homme(kévin, grand, brun, jeune).
homme(gaston, moyen, blond, mur).
homme(rémi, moyen, blond, vieux).

% femme(nom, taille, couleur_cheveux, age)
femme(martine, petit, blond, mur).
femme(odile, moyen, blond, jeune).
femme(léa, petit, brun, mur).
femme(elsa, grand, brun, jeune).
femme(sylvie, moyen, blond, jeune).
femme(julie, petit, blond, mur).
femme(mathilde, grand, blond, mur).
femme(anne, grand, blond, mur).

% gout(nom, musique, litterature, sport)
gout(luc, pop, policier, tennis).
gout(kévin, jazz, science_fiction, jogging).
gout(gaston, classique, aventure, natation).
gout(rémi, classique, aventure, jogging).
gout(martine, classique, aventure, natation).
gout(odile, classique, science_fiction, natation).
gout(léa, classique, policier, tennis).
gout(elsa, jazz, science_fiction, natation).
gout(sylvie, classique, science_fiction, natation).
gout(julie, pop, policier, tennis).
gout(mathilde, classique, policier, tennis).
gout(anne, classique, aventure, natation).

% recherche(nom, taille_recherchee, couleur_cheveux_recherchee, age_recherche)
recherche(luc, moyen, roux, jeune).
recherche(gaston, petit, blond, jeune).
recherche(kévin, moyen, roux, jeune).
recherche(rémi, petit, blond, mur).
recherche(martine, moyen, blond, mur).
recherche(odile, grand, brun, jeune).
recherche(léa, moyen, brun, mur).
recherche(elsa, grand, brun, mur).
recherche(sylvie, grand, sans_avis, mur).
recherche(julie, petit, roux, jeune).
recherche(mathilde, grand, brun, mur).
recherche(anne, grand, blond, vieux).
