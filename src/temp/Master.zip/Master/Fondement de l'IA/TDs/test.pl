% Bases de connaissance

Personne(ahmed).
Personne(meriem).
Personne(rachid).
compte(ahmed, 7500).
compte(meriem, 9000).
compte(rachid, 23000).
mois(15, september).
moi_hijri(1, ramadan).

% Regles

en_crise(X) :- personne(X), compte(X,  Y), Y < 4000.
en_crise(X) :- personne(X), compte(X,  Y), Y < 15000.
en_crise(X) :- personne(X), compte(X,  Y), Y < 5000.
crise(X) :- 