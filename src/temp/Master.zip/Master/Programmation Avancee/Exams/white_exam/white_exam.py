import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1.Importation des donnees
salaries = pd.read_excel('../TPs/TP3/Data/salaries.xlsx')
# print('Column data type:')
# print(salaries.dtypes)
# Oui on peut voir l'existance des valeur manqante dans le dataset

# 2.Preparation et Nettoyage des Donnees

# Vérifier les valeurs manquantes
# print("Valeurs manquantes par colonne :")
# print(salaries.isnull().sum())

# Missed values deleting
# salaries_cleaned = salaries.dropna()
salaries_clean = salaries[salaries.isnull().sum(axis=1) < 2]

# Fill missed values
salaries.fillna(salaries.mean(numeric_only=True), inplace=True)

# Missed values exist in the 'Notes' and the 'Status' columns

# Number of rows left after cleaning
salaries_rows_deleted = len(salaries) - len(salaries_clean)
# print(salaries_rows_deleted)

# Rename columns
salaries.rename(columns={
    'Id': 'new_id',
    'EmployeeName': 'E_N',
    'JobTitle': 'J_T',
    'BasePay': 'B_P',
    'OvertimePay': 'O_P',
    'OtherPay': 'Oth_P',
    'Benefits': 'B',
    'Totale_Pay': 'T_P',
    'TotalPayBenefits': 'T_P_B',
    'Year':'Y',
    'Notes':'N',
    'Agency':'A',
    'Status':'S'
}, inplace=True)

# 3. Analyse Exploratoire des Donnees

# Statistics calculus and description
description = salaries_clean.describe()
print("\nStatistiques descriptives :")
print(description)

# Mean of each column
moyennes = salaries_clean.mean(numeric_only=True)
print("\nMoyenne de chaque colonne numérique :")
print(moyennes)

# Intressting Distrubtion
asymetrie = salaries_clean.skew(numeric_only=True)
print("\nAsymétrie des colonnes :")
print(asymetrie)

# 4. Visualisation des Donnees

# Histogram plot
salaries_clean.hist(bins=10, figsize=(10, 8), edgecolor='black')
plt.suptitle("Histogramme des colonnes numériques")
plt.show()

# Scatter plot
plt.figure(figsize=(8, 6))
sns.scatterplot(data=salaries_clean, x='BasePay', y='OvertimePay')
plt.title("Scatter plot de BasePay vs. OvertimePay")
plt.xlabel("Salaire")
plt.ylabel("Age")
plt.show()