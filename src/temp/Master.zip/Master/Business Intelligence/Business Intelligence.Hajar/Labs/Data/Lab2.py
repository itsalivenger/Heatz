# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns

# cdc = pd.read_csv("cdc.csv")

# Question 1:
# print("Dimensions of the data frame:", cdc.shape)

# Question 2: 
# print("First few entries:\n", cdc.head())
# print("Last few entries:\n", cdc.tail())

# Question 3:
# print("Summary of weight:\n", cdc['weight'].describe())

# Question 4:
# print("Mean weight:", cdc['weight'].mean())
# print("Variance of weight:", cdc['weight'].var())
# print("Median weight:", cdc['weight'].median())

# Question 5:
# smoke_count = cdc['smoke100'].value_counts()
# print("Frequency distribution of smoke100:\n", smoke_count)
# relative_frequency = cdc['smoke100'].value_counts(normalize=True)
# print("Relative frequency distribution of smoke100:\n", relative_frequency)

# Question 6:
# smoke_count.plot(kind='bar')
# plt.title("Frequency of Smoking 100+ Cigarettes")
# plt.xlabel("Smoke 100 (0 = No, 1 = Yes)")
# plt.ylabel("Frequency")
# plt.show()

# Question 7: Done already in q6

# Question 8:
# smoke_gender_table = pd.crosstab(cdc['gender'], cdc['smoke100'])
# print("Smoking status by gender:\n", smoke_gender_table)

# Question 9:
# smoke_gender_table.plot(kind='bar', stacked=True)
# plt.title("Smoking Status by Gender")
# plt.xlabel("Gender")
# plt.ylabel("Count")
# plt.legend(title="Smoke 100")
# plt.show()

# Question 10:
# print("Specific entries:\n", cdc.iloc[566, 5])
# print("First 10 entries in column 6:\n", cdc.iloc[0:10, 5])
# print("First 10 rows:\n", cdc.iloc[0:10, :])

# Question 11:
# print("Men in dataset:\n", cdc[cdc['gender'] == "m"])
# print("People over 30:\n", cdc[cdc['age'] > 30])

# Question 12:
# mdata = cdc[cdc['gender'] == "m"]
# print("Data for men:\n", mdata)

# Question 13:
# m_and_over30 = cdc[(cdc['gender'] == "m") & (cdc['age'] > 30)]
# print("Data for men over 30:\n", m_and_over30)

# Question 14:
# plt.boxplot(cdc['height'])
# plt.title("Box Plot of Height")
# plt.ylabel("Height")
# plt.show()

# Question 15:
# print("Summary of height:\n", cdc['height'].describe())

# Question 16:
# sns.boxplot(x='gender', y='height', data=cdc)
# plt.title("Height Distribution by Gender")
# plt.xlabel("Gender")
# plt.ylabel("Height")
# plt.show()

# Question 17:
# plt.hist(cdc['age'], bins=20)
# plt.title("Histogram of Age")
# plt.xlabel("Age")
# plt.ylabel("Frequency")
# plt.show()

# Question 18:
# plt.hist(cdc['age'], bins=50)
# plt.title("Histogram of Age with 50 Bins")
# plt.xlabel("Age")
# plt.ylabel("Frequency")
# plt.show()

# # Question 19:
# sns.scatterplot(x='weight', y='wtdesire', data=cdc, color="blue")
# plt.title("Scatterplot of Weight vs. Desired Weight")
# plt.xlabel("Current Weight")
# plt.ylabel("Desired Weight")
# plt.show()

# # Question 20:
# cdc['wdiff'] = cdc['wtdesire'] - cdc['weight']
# print("New variable 'wdiff' (weight difference):\n", cdc['wdiff'].head())

# Question 21:
# print("Interpretation of wdiff: Counts by value\n", cdc['wdiff'].value_counts())

# Question 22:
# print("Summary of wdiff:\n", cdc['wdiff'].describe())
# plt.hist(cdc['wdiff'], bins=20)
# plt.title("Distribution of Weight Difference (wdiff)")
# plt.xlabel("Weight Difference")
# plt.ylabel("Frequency")
# plt.show()

# Question 23:
# sns.boxplot(x='gender', y='wdiff', data=cdc)
# plt.title("Weight Difference by Gender")
# plt.xlabel("Gender")
# plt.ylabel("Weight Difference (Desired - Current)")
# plt.show()

# # Question 24:
# mean_weight = cdc['weight'].mean()
# std_dev_weight = cdc['weight'].std()
# print("Mean weight:", mean_weight)
# print("Standard deviation of weight:", std_dev_weight)
# within_one_sd = ((cdc['weight'] > (mean_weight - std_dev_weight)) & 
#                  (cdc['weight'] < (mean_weight + std_dev_weight))).mean()
# print("Proportion of weights within one standard deviation of the mean:", within_one_sd)

# # Question 25:

# Boxplot
# sns.boxplot(x='gender', y='age', data=cdc)
# plt.title("Box Plot of Age by Gender")
# plt.show()

# # Histogram
# plt.hist(cdc['age'], bins=30)
# plt.title("Histogram of Age")
# plt.show()

# # Bar plot
# sns.countplot(x='smoke100', data=cdc)
# plt.title("Bar Plot of Smoking 100+ Cigarettes")
# plt.show()

# # Column plot
# cdc.groupby('smoke100').size().plot(kind='bar')
# plt.title("Column Plot of Smoking Status")
# plt.xlabel("Smoke 100")
# plt.ylabel("Count")
# plt.show()
