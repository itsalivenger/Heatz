source("http://www.openintro.org/stat/data/cdc.R")
# names(cdc)
# dim(cdc)
# head(cdc)
# tail(cdc)
# summary(cdc$weight)
# mean(cdc$weight)
# var(cdc$weight)
# median(cdc$weight)
# table(cdc$smoke100)
# table(cdc$smoke100)/20000
# barplot(table(cdc$smoke100))
# smoke <- table(cdc$smoke100)
# barplot(smoke)
# table(cdc$gender, cdc$smoke100)
# mosaicplot(table(cdc$gender, cdc$smoke100))
# cdc[567, 6]
# cdc[1:10, 6]
# cdc[1:10, ]
# mdata <- subset(cdc, gender == "m")
# mdata <- subset(cdc, gender == "m" $ age > 30)
# boxplot(cdc$height)
# summary(cdc$height)
# boxplot(cdc$height ~ cdc$gender)
# hist(cdc$age)
# hist(cdc$age, breaks = 50)
# library(tidyverse)
# ggplot(data = cdc) + geom_point(mapping = aes(x = weight, y = wtdesire),color="blue")


wdiff = cdc$wtdesire - cdc$weight
head(wdiff) #numeric vector

#Person's weight equals the desired person's weight
#Person doesnt have dysmorphia
#positive then the desired weight is greater than the actual weight 
#Negative then the opposite!

summary(wdiff)
library(ggplot2)

ggplot(data = cdc, aes(x = wdiff)) + 
  geom_histogram(binwidth = 5, fill = "blue", color = "white") + 
  labs(title = "Distribution of Weight Difference (wdiff)", x = "wdiff", y = "Count")

ggplot(data = cdc, aes(y = wdiff)) + 
  geom_boxplot(fill = "blue") + 
  labs(title = "Box Plot of Weight Difference (wdiff)", y = "wdiff")

#People tend to desire weights different than their own

ggplot(data = cdc, aes(x = gender, y = wdiff)) + 
  geom_boxplot(fill = c("blue", "pink")) + 
  labs(title = "Weight Difference by Gender", x = "Gender", y = "Weight Difference (wdiff)")

#Men tend to gain weight, in the other hand women tend to lose weight

mean_weight <- mean(cdc$weight)
sd_weight <- sd(cdc$weight)

lower_bound <- mean_weight - sd_weight
upper_bound <- mean_weight + sd_weight

proportion_within_one_sd <- mean(cdc$weight >= lower_bound & cdc$weight <= upper_bound)
proportion_within_one_sd

?geom_boxplot()
?geom_histogram()
?geom_bar()
?geom_col()
?geom_bar()

library(tidyverse)
ggplot(data = cdc, aes(x = gender, y = weight)) + 
  geom_boxplot() +
  labs(title = "Box Plot For Weight And Gender", x = "Gender", y = "Weight")

ggplot(data = cdc, aes(x = weight)) + 
  geom_histogram(binwidth = 5, fill = "blue", color = "white") + 
  labs(title = "Histogram of Weights", x = "Weight", y = "Count")

ggplot(data = cdc, aes(x = smoke100)) + 
  geom_bar(fill = "lightblue", color = "black") + 
  labs(title = "Bar Plot of Smoking Status", x = "Smoked 100 Cigarettes", y = "Count")

ggplot(data = cdc, aes(x = smoke100)) + 
  geom_col(fill = "lightgreen", color = "black") + 
  labs(title = "Column Plot of Smoking Status", x = "Smoked 100 Cigarettes", y = "Count")

ggplot(data = cdc, aes(x = factor(smoke100))) + 
  geom_bar(fill = "purple") + 
  coord_polar() + 
  labs(title = "Polar Bar Chart of Smoking Status", x = "Smoked 100 Cigarettes", y = "Count")

ggplot(data = cdc, aes(x = smoke100)) + 
  geom_bar(fill = "orange", color = "black") + 
  coord_flip() + 
  labs(title = "Flipped Bar Plot of Smoking Status", x = "Count", y = "Smoked 100 Cigarettes")